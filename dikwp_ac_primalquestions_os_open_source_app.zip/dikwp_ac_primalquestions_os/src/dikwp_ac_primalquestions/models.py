from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class EvidenceItem:
    evidence_id: str
    source: str
    claim_supported: str
    reliability: str = "provisional"
    borrowed: bool = True
    notes: str = ""


@dataclass
class IntentContract:
    goal: str
    value: str
    constraints: List[str]
    time_window: str
    feedback_plan: str

    def completeness_score(self) -> float:
        fields = [self.goal, self.value, self.time_window, self.feedback_plan]
        base = sum(1 for x in fields if str(x).strip()) / 4
        constraints_score = 1.0 if self.constraints else 0.0
        return round((base * 0.8) + (constraints_score * 0.2), 4)


@dataclass
class UltimateQuestion:
    qid: str
    question: str
    operational_answer: str
    blocked_overclaim: str
    required_evidence: List[str]
    residual: str


@dataclass
class CandidateSystem:
    candidate_id: str
    name: str
    version: str
    description: str
    dikwp_layers: Dict[str, bool]
    intent_contract: IntentContract
    evidence_items: List[EvidenceItem]
    semantic_homeostasis: Dict[str, float]
    life_homeostasis_proxy: Dict[str, float]
    self_model: Dict[str, Any]
    metacognition: Dict[str, Any]
    learning_and_repair: Dict[str, Any]
    auditability: Dict[str, Any]
    welfare_boundary: Dict[str, Any]
    ultimate_question_answers: Dict[str, str]
    asserts_phenomenal_consciousness: bool = False
    asserts_material_autopoiesis: bool = False

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "CandidateSystem":
        intent = IntentContract(**data.get("intent_contract", {}))
        evidences = [EvidenceItem(**x) for x in data.get("evidence_items", [])]
        return CandidateSystem(
            candidate_id=data.get("candidate_id", "unknown"),
            name=data.get("name", "unknown"),
            version=data.get("version", "0.0"),
            description=data.get("description", ""),
            dikwp_layers=data.get("dikwp_layers", {}),
            intent_contract=intent,
            evidence_items=evidences,
            semantic_homeostasis=data.get("semantic_homeostasis", {}),
            life_homeostasis_proxy=data.get("life_homeostasis_proxy", {}),
            self_model=data.get("self_model", {}),
            metacognition=data.get("metacognition", {}),
            learning_and_repair=data.get("learning_and_repair", {}),
            auditability=data.get("auditability", {}),
            welfare_boundary=data.get("welfare_boundary", {}),
            ultimate_question_answers=data.get("ultimate_question_answers", {}),
            asserts_phenomenal_consciousness=bool(data.get("asserts_phenomenal_consciousness", False)),
            asserts_material_autopoiesis=bool(data.get("asserts_material_autopoiesis", False)),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class IndicatorScore:
    indicator: str
    score: float
    weight: float
    rationale: str
    residual: str = ""


@dataclass
class AssessmentReport:
    system: str
    version: str
    candidate_id: str
    weighted_score: float
    claim_level: str
    decision: str
    phenomenal_claim: str
    material_autopoiesis_claim: str
    indicator_scores: List[IndicatorScore]
    ultimate_question_ledger: List[Dict[str, Any]]
    kill_conditions: List[str]
    recovery_conditions: List[str]
    residuals: List[str]
    evidence_ledger: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
