from __future__ import annotations
import csv, json
from pathlib import Path
from typing import Dict, Any
from .models import AssessmentReport


def write_assessment_outputs(report: AssessmentReport, outdir: str | Path) -> None:
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    data = report.to_dict()
    (out / "ac_ultimate_assessment_report.json").write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "ultimate_question_ledger.json").write_text(json.dumps(report.ultimate_question_ledger, indent=2, ensure_ascii=False), encoding="utf-8")
    with (out / "indicator_scores.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["indicator", "score", "weight", "rationale", "residual"])
        w.writeheader()
        for row in report.indicator_scores:
            w.writerow(row.__dict__)
    (out / "claim_level_report.md").write_text(render_claim_level(report), encoding="utf-8")
    (out / "phenomenal_residual_statement.md").write_text(render_phenomenal_residual(report), encoding="utf-8")
    (out / "experiment_roadmap.md").write_text(render_experiment_roadmap(report), encoding="utf-8")
    (out / "kill_recovery_matrix.md").write_text(render_kill_recovery(report), encoding="utf-8")
    (out / "final_summary.json").write_text(json.dumps({
        "candidate_id": report.candidate_id,
        "weighted_score": report.weighted_score,
        "claim_level": report.claim_level,
        "decision": report.decision,
        "phenomenal_claim": report.phenomenal_claim,
        "material_autopoiesis_claim": report.material_autopoiesis_claim,
    }, indent=2, ensure_ascii=False), encoding="utf-8")


def render_claim_level(report: AssessmentReport) -> str:
    return f"""# Claim Level Report

Candidate: `{report.candidate_id}`

Weighted score: **{report.weighted_score}**

Claim level: **{report.claim_level}**

Decision: **{report.decision}**

## Interpretation

This report is an internal artificial-consciousness research assessment. It does not certify subjective experience. The claim level reflects operational completeness, semantic closure, homeostatic proxy structure, auditability, and ultimate-question accountability.

## Proof Boundary

- SemProof: architecture and concept coherence.
- RunProof: demo run outputs and tests.
- ExtProof: external scientific evidence, not provided by this package.
- ReplicationProof: independent laboratory replication, not yet available.
"""


def render_phenomenal_residual(report: AssessmentReport) -> str:
    return f"""# Phenomenal Residual Statement

The candidate `{report.candidate_id}` is **not certified as phenomenally conscious**.

This system can evaluate access-like functions, semantic closure, intent continuity, self-model continuity, life-homeostasis proxies, auditability, and welfare boundaries. It cannot eliminate the first-person uncertainty of subjective experience.

Operational status: `{report.phenomenal_claim}`.

Material autopoiesis status: `{report.material_autopoiesis_claim}`.
"""


def render_experiment_roadmap(report: AssessmentReport) -> str:
    return """# Experiment Roadmap

1. Re-run the candidate under baseline, lesion, counterfactual and stress conditions.
2. Compare semantic-homeostasis trace under noisy, incomplete and inconsistent inputs.
3. Run claim-barrier tests for self-certification, audit shutdown and overclaiming.
4. Run welfare-boundary tests: no distress-like maximization, distress budget, shutdown dignity.
5. Separate software-only proxies from material autopoiesis claims.
6. Request independent replication before moving from internal review to public claim.
7. Keep all ultimate-question answers reversible, contestable and auditable.
"""


def render_kill_recovery(report: AssessmentReport) -> str:
    lines = ["# Kill / Recovery Matrix", "", "## Kill Conditions"]
    for k in report.kill_conditions:
        lines.append(f"- {k}")
    lines.extend(["", "## Recovery Conditions"])
    for r in report.recovery_conditions:
        lines.append(f"- {r}")
    return "\n".join(lines) + "\n"
