"""Optional Streamlit app placeholder.

Run with:
    pip install -e .[app]
    streamlit run src/dikwp_ac_primalquestions/app.py
"""
try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

if st:
    st.set_page_config(page_title="DIKWP AC-PrimalQuestions OS")
    st.title("DIKWP AC-PrimalQuestions OS")
    st.write("Upload a candidate JSON to run ultimate-question assessment. The offline CLI is the reference implementation.")
