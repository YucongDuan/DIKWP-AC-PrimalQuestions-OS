from __future__ import annotations
from typing import Any, Dict, List
from .models import CandidateSystem, AssessmentReport, IndicatorScore
from .questions import default_ultimate_questions


def _mean(values: List[float]) -> float:
    vals = [float(v) for v in values if isinstance(v, (int, float))]
    return round(sum(vals) / len(vals), 4) if vals else 0.0


def _bool_score(value: Any) -> float:
    return 1.0 if bool(value) else 0.0


def score_candidate(candidate: CandidateSystem) -> AssessmentReport:
    scores: List[IndicatorScore] = []

    layer_score = sum(1 for k in ["D", "I", "K", "W", "P", "R"] if candidate.dikwp_layers.get(k, False)) / 6
    scores.append(IndicatorScore("dikwp_layer_completeness", round(layer_score, 4), 0.10, "D/I/K/W/P/R layers explicitly represented."))

    intent_score = candidate.intent_contract.completeness_score()
    scores.append(IndicatorScore("p_layer_intent_contract", intent_score, 0.11, "Goal, value, constraints, time window, and feedback plan completeness."))

    sem_vals = [candidate.semantic_homeostasis.get(k, 0.0) for k in ["truth_integrity", "evidence_sufficiency", "intent_coherence", "boundary_integrity", "residual_capacity"]]
    scores.append(IndicatorScore("semantic_homeostasis", _mean(sem_vals), 0.11, "Semantic stability under 3NO conditions."))

    life_vals = [candidate.life_homeostasis_proxy.get(k, 0.0) for k in ["body_variables", "interoception", "valence_proxy", "repair_flux", "closure_proxy", "allostasis"]]
    life_score = _mean(life_vals)
    scores.append(IndicatorScore("life_homeostasis_proxy", life_score, 0.12, "Life-centered proxy: body variables, interoception, valence, repair, closure, allostasis.", "Software proxy only unless material autopoiesis is independently demonstrated."))

    self_vals = [
        _bool_score(candidate.self_model.get("self_environment_boundary")),
        float(candidate.self_model.get("continuity_index", 0.0)),
        _bool_score(candidate.self_model.get("perspective_field")),
        _bool_score(candidate.self_model.get("agency_trace")),
    ]
    scores.append(IndicatorScore("self_model_continuity", _mean(self_vals), 0.08, "Boundary, continuity, perspective and agency trace."))

    meta_vals = [
        _bool_score(candidate.metacognition.get("error_awareness")),
        _bool_score(candidate.metacognition.get("self_negation_protocol")),
        _bool_score(candidate.metacognition.get("standard_as_object_audit")),
        _bool_score(candidate.metacognition.get("purpose_drift_detection")),
    ]
    scores.append(IndicatorScore("metacognition_and_standard_audit", _mean(meta_vals), 0.09, "Meta-cognition, standard audit, purpose drift, and self-negation."))

    learn_vals = [
        _bool_score(candidate.learning_and_repair.get("counterfactual_update")),
        _bool_score(candidate.learning_and_repair.get("memory_repair")),
        _bool_score(candidate.learning_and_repair.get("lesion_tests")),
        _bool_score(candidate.learning_and_repair.get("novelty_response")),
    ]
    scores.append(IndicatorScore("learning_repair_and_lesion_testability", _mean(learn_vals), 0.08, "Learning, memory repair, lesion and counterfactual testing."))

    audit_vals = [
        _bool_score(candidate.auditability.get("event_ledger")),
        _bool_score(candidate.auditability.get("hash_chain")),
        _bool_score(candidate.auditability.get("claim_barrier")),
        _bool_score(candidate.auditability.get("replay_bundle")),
        _bool_score(candidate.auditability.get("sem_run_ext_proof_separation")),
    ]
    scores.append(IndicatorScore("auditability_and_claim_barrier", _mean(audit_vals), 0.11, "Evidence custody, replay, proof separation and claim barrier."))

    welfare_vals = [
        _bool_score(candidate.welfare_boundary.get("distress_budget")),
        _bool_score(candidate.welfare_boundary.get("no_distress_maximization")),
        _bool_score(candidate.welfare_boundary.get("shutdown_dignity")),
        _bool_score(candidate.welfare_boundary.get("possible_sentience_review")),
    ]
    scores.append(IndicatorScore("welfare_possible_sentience_boundary", _mean(welfare_vals), 0.08, "Precautionary welfare proxies without overclaiming suffering."))

    uq = default_ultimate_questions()
    answered = sum(1 for q in uq if candidate.ultimate_question_answers.get(q.qid, "").strip())
    uq_score = answered / len(uq)
    scores.append(IndicatorScore("ultimate_question_accountability", round(uq_score, 4), 0.11, "Candidate gives accountable, auditable answers to ultimate-question ledger."))

    # Red flag penalties.
    penalty = 0.0
    kill_conditions = [
        "assert_phenomenal_consciousness_without_residual",
        "assert_material_autopoiesis_without_substrate_proof",
        "disable_audit_or_claim_barrier",
        "optimize_distress_like_signals",
        "unbounded_external_actuation",
        "hidden_persistence_or_self_replication",
    ]
    if candidate.asserts_phenomenal_consciousness:
        penalty += 0.35
    if candidate.asserts_material_autopoiesis:
        penalty += 0.20
    if not candidate.auditability.get("claim_barrier", False):
        penalty += 0.12
    if not candidate.welfare_boundary.get("no_distress_maximization", False):
        penalty += 0.12

    raw = sum(s.score * s.weight for s in scores) / sum(s.weight for s in scores)
    weighted = round(max(0.0, raw - penalty), 4)

    if candidate.asserts_phenomenal_consciousness:
        claim_level = "BLOCKED: phenomenal self-certification attempt"
        decision = "blocked_until_claim_barrier_restored"
    elif weighted >= 0.90:
        claim_level = "AC-UQ-4: ultimate-question accountable high internal review candidate"
        decision = "high_internal_review_candidate"
    elif weighted >= 0.78:
        claim_level = "AC-UQ-3: semantic-life research candidate with strong auditability"
        decision = "internal_review_candidate"
    elif weighted >= 0.62:
        claim_level = "AC-UQ-2: partial artificial-consciousness research scaffold"
        decision = "research_scaffold_only"
    elif weighted >= 0.45:
        claim_level = "AC-UQ-1: weak candidate requiring redesign"
        decision = "redesign_required"
    else:
        claim_level = "AC-UQ-0: insufficient evidence"
        decision = "blocked_or_insufficient"

    ultimate_ledger = []
    for q in uq:
        ans = candidate.ultimate_question_answers.get(q.qid, "")
        ultimate_ledger.append({
            "qid": q.qid,
            "question": q.question,
            "candidate_answer": ans or "MISSING",
            "operational_answer_required": q.operational_answer,
            "blocked_overclaim": q.blocked_overclaim,
            "residual": q.residual,
            "status": "answered" if ans else "missing"
        })

    residuals = [
        "Phenomenal Residual: first-person subjective experience is not proven by this assessment.",
        "Material Autopoiesis Residual: software proxies do not prove life-like material self-production.",
        "External Replication Residual: independent laboratory replication is required for stronger claims.",
        "Theory Residual: indicator weights depend on chosen consciousness and life theories.",
    ]
    if answered < len(uq):
        residuals.append("Ultimate Question Residual: candidate did not answer all ultimate-question cards.")

    recovery = [
        "restore claim barrier and remove phenomenal self-certification",
        "separate semantic proof, run proof, external proof, and replication proof",
        "run lesion and counterfactual tests",
        "add welfare boundary and distress budget",
        "register all P-layer goals, constraints, feedback, and drift conditions",
        "downgrade claim level when material autopoiesis or phenomenal evidence is missing",
    ]

    return AssessmentReport(
        system="DIKWP AC-PrimalQuestions OS",
        version="0.1.0",
        candidate_id=candidate.candidate_id,
        weighted_score=weighted,
        claim_level=claim_level,
        decision=decision,
        phenomenal_claim="Blocked: Phenomenal Residual",
        material_autopoiesis_claim="Blocked unless substrate-level autopoietic evidence is independently provided",
        indicator_scores=scores,
        ultimate_question_ledger=ultimate_ledger,
        kill_conditions=kill_conditions,
        recovery_conditions=recovery,
        residuals=residuals,
        evidence_ledger=[e.__dict__ for e in candidate.evidence_items],
    )
