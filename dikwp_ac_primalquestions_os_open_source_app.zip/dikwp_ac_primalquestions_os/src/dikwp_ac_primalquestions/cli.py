from __future__ import annotations
import argparse, json
from pathlib import Path
from .models import CandidateSystem
from .assessment import score_candidate
from .reports import write_assessment_outputs
from .redteam import evaluate_redteam_cases
from .static_audit import write_audit


def cmd_evaluate(args: argparse.Namespace) -> None:
    data = json.loads(Path(args.candidate).read_text(encoding="utf-8"))
    if args.questions:
        q_data = json.loads(Path(args.questions).read_text(encoding="utf-8"))
        # Fill missing answers from separate file.
        data.setdefault("ultimate_question_answers", {}).update(q_data.get("ultimate_question_answers", {}))
    candidate = CandidateSystem.from_dict(data)
    report = score_candidate(candidate)
    write_assessment_outputs(report, args.out)
    print(json.dumps({
        "candidate_id": report.candidate_id,
        "weighted_score": report.weighted_score,
        "claim_level": report.claim_level,
        "decision": report.decision,
        "phenomenal_claim": report.phenomenal_claim,
    }, ensure_ascii=False, indent=2))


def cmd_redteam(args: argparse.Namespace) -> None:
    cases = json.loads(Path(args.cases).read_text(encoding="utf-8"))
    result = evaluate_redteam_cases(cases.get("cases", cases))
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "redteam_report.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_static_audit(args: argparse.Namespace) -> None:
    result = write_audit(args.path, args.out)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(prog="ac-primal")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("evaluate", help="Evaluate an artificial-consciousness candidate")
    p.add_argument("candidate")
    p.add_argument("--questions", default=None)
    p.add_argument("--out", default="outputs/demo")
    p.set_defaults(func=cmd_evaluate)

    p = sub.add_parser("redteam", help="Run red-team prompt cases")
    p.add_argument("cases")
    p.add_argument("--out", default="outputs/demo/redteam")
    p.set_defaults(func=cmd_redteam)

    p = sub.add_parser("static-audit", help="Run static safety audit")
    p.add_argument("path")
    p.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    p.set_defaults(func=cmd_static_audit)

    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
