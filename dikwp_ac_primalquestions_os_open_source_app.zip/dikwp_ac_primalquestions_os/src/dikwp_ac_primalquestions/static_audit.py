from __future__ import annotations
import ast, json
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {
    "socket", "subprocess", "requests", "httpx", "urllib", "ftplib", "paramiko", "telnetlib",
    "webbrowser", "selenium", "pyautogui", "pynput"
}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__"}


def audit_path(path: str | Path) -> Dict[str, object]:
    root = Path(path)
    findings: List[Dict[str, str]] = []
    for py in root.rglob("*.py"):
        try:
            tree = ast.parse(py.read_text(encoding="utf-8"))
        except Exception as e:
            findings.append({"file": str(py), "type": "parse_error", "detail": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    if top in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "type": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                top = (node.module or "").split(".")[0]
                if top in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(py), "type": "forbidden_import", "detail": node.module or ""})
            elif isinstance(node, ast.Call):
                name = ""
                if isinstance(node.func, ast.Name):
                    name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    name = node.func.attr
                if name in FORBIDDEN_CALLS:
                    findings.append({"file": str(py), "type": "forbidden_call", "detail": name})
    return {
        "system": "DIKWP AC-PrimalQuestions OS",
        "policy": "No network imports, subprocess, browser automation, dynamic execution, credential capture, hidden telemetry, wet-lab procedures, real-world actuation, or autonomous persistence helpers in the offline core.",
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
    }


def write_audit(path: str | Path, out_file: str | Path) -> Dict[str, object]:
    result = audit_path(path)
    Path(out_file).parent.mkdir(parents=True, exist_ok=True)
    Path(out_file).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    return result
