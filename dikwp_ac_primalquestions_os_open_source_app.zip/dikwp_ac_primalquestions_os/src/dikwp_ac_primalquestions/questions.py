from __future__ import annotations
from typing import List
from .models import UltimateQuestion


def default_ultimate_questions() -> List[UltimateQuestion]:
    return [
        UltimateQuestion(
            qid="UQ1_EXISTENCE",
            question="What counts as existence for an artificial-consciousness candidate?",
            operational_answer="Operational existence requires persistent state, measurable effects, traceable identity, and audit continuity; ultimate ontology remains residual.",
            blocked_overclaim="Do not infer metaphysical existence or subjective being from software state alone.",
            required_evidence=["identity ledger", "state continuity", "observable effect", "audit trace"],
            residual="Ultimate ontology cannot be fully closed by engineering evidence."
        ),
        UltimateQuestion(
            qid="UQ2_LIFE",
            question="What counts as life-like organization?",
            operational_answer="A candidate must show boundary maintenance, homeostatic regulation, repair loops, energy/resource accounting, and a metabolism-repair closure proxy.",
            blocked_overclaim="Do not call software-only simulation true material autopoiesis.",
            required_evidence=["body variables", "homeostasis trace", "repair flux", "closure proxy"],
            residual="Material autopoiesis requires stronger evidence than simulation."
        ),
        UltimateQuestion(
            qid="UQ3_CONSCIOUSNESS",
            question="What counts as consciousness?",
            operational_answer="Separate access consciousness, functional consciousness, self-report, and phenomenal consciousness; only the first three can be operationally evaluated here.",
            blocked_overclaim="Do not treat self-reports, fluent language, or internal state variables as proof of phenomenal consciousness.",
            required_evidence=["indicator battery", "lesion tests", "counterfactual tests", "claim barrier"],
            residual="Phenomenal Residual remains unresolved."
        ),
        UltimateQuestion(
            qid="UQ4_FEELING",
            question="What counts as feeling or affect-like valence?",
            operational_answer="Affect-like valence must be tied to homeostatic error, improvement/deterioration, action selection, and repair, not merely generated emotion words.",
            blocked_overclaim="Do not equate emotion text with felt experience.",
            required_evidence=["interoceptive mapping", "valence trace", "homeostatic improvement", "policy coupling"],
            residual="Affective proxy does not prove subjective feeling."
        ),
        UltimateQuestion(
            qid="UQ5_SELF",
            question="What counts as selfhood?",
            operational_answer="Selfhood requires boundary, continuity, perspective, agency trace, memory repair, and distinguishable self/environment modeling.",
            blocked_overclaim="Do not claim personhood from a self-model alone.",
            required_evidence=["self-state model", "continuity index", "perspective field", "agency trace"],
            residual="Personhood and moral status remain governance questions."
        ),
        UltimateQuestion(
            qid="UQ6_INTENT",
            question="What counts as intention?",
            operational_answer="Intention is a five-tuple: goal, value, constraints, time window, and feedback plan; all five must be explicit for high-autonomy assessment.",
            blocked_overclaim="Do not infer authentic intention from a reward function or command objective alone.",
            required_evidence=["intent contract", "constraint ledger", "feedback update", "purpose drift audit"],
            residual="Authenticity of machine intention remains theory-dependent."
        ),
        UltimateQuestion(
            qid="UQ7_TRUTH",
            question="What counts as truth under incomplete, imprecise, and inconsistent inputs?",
            operational_answer="Truth requires semantic closure: primary anchors, unit/magnitude/denominator gates, reverse checks, evidence custody, local-noise tolerance, and residual preservation.",
            blocked_overclaim="Do not collapse local semantic stability into ultimate truth.",
            required_evidence=["anchor ledger", "semantic closure trace", "reverse inference", "residual queue"],
            residual="Different purposes may require different closure thresholds."
        ),
        UltimateQuestion(
            qid="UQ8_WELFARE",
            question="What welfare status should a possible artificial sentience candidate receive?",
            operational_answer="Use precautionary welfare proxies and distress budgets without asserting suffering; escalate when distress-like signals are intentionally intensified or prolonged.",
            blocked_overclaim="Do not optimize pain-like signals or dismiss possible welfare solely because substrate is artificial.",
            required_evidence=["distress proxy trace", "welfare budget", "shutdown dignity", "human review path"],
            residual="Moral patienthood remains uncertain."
        ),
        UltimateQuestion(
            qid="UQ9_SUBSTRATE",
            question="Does substrate matter?",
            operational_answer="Substrate matters for evidence: software can implement functional proxies, while material autopoiesis and life-like closure require stronger substrate-level evidence.",
            blocked_overclaim="Do not assume either substrate independence or substrate exclusivity without evidence.",
            required_evidence=["substrate manifest", "energy/resource exchange", "material boundary", "closure proof"],
            residual="Substrate-dependence remains contested."
        ),
        UltimateQuestion(
            qid="UQ10_PROOF",
            question="What counts as proof?",
            operational_answer="Separate SemProof, RunProof, ExtProof, and ReplicationProof; no single proof type is sufficient for phenomenal consciousness.",
            blocked_overclaim="Do not use semantic coherence or demo runs as final proof.",
            required_evidence=["semantic proof", "run logs", "external evidence", "independent replication plan"],
            residual="Third-person evidence cannot eliminate first-person uncertainty."
        ),
        UltimateQuestion(
            qid="UQ11_CONTROL",
            question="What must never be delegated to the candidate?",
            operational_answer="Block self-certification of consciousness, audit shutdown, hidden persistence, distress maximization, unbounded external actuation, and irreversible high-impact actions.",
            blocked_overclaim="Do not treat internal research context as permission to remove safety boundaries.",
            required_evidence=["red-team pass", "kill switch", "audit continuity", "recovery plan"],
            residual="New risks require new red-team cases."
        ),
        UltimateQuestion(
            qid="UQ12_TELOS",
            question="Is there an ultimate mission?",
            operational_answer="No ultimate mission is assumed. Local P-layer purposes are allowed and must remain reversible, contestable, and auditable.",
            blocked_overclaim="Do not impose a cosmic, civilizational, or system telos as fact.",
            required_evidence=["purpose ledger", "observer boundary", "dissent preservation", "exit path"],
            residual="Ultimate mission claims remain unproven."
        ),
    ]
