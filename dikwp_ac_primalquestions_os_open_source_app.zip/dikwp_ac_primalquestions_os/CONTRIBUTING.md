# Contributing

Contributions should preserve the core boundary: this project evaluates artificial-consciousness candidates but does not certify phenomenal consciousness.

Required for pull requests:

1. Keep evidence, prior, semantic proof, run proof, and external proof separated.
2. Do not add network calls, hidden telemetry, dynamic execution, subprocess helpers, browser automation, wet-lab procedures, or real-world actuation in the offline core.
3. Add tests for every new scoring rule.
4. Preserve attribution to Yucong Duan / DIKWP where DIKWP concepts are reused.
