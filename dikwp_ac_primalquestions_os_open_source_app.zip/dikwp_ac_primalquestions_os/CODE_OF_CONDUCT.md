# Code of Conduct

This project is for responsible research. Participants should avoid overclaiming consciousness, misleading welfare claims, harassment, doxxing, unsafe experimentation, or pressure to remove audit boundaries.
