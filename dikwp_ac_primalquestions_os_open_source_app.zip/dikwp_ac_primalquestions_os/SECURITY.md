# Security Policy

The offline core must not contain hidden telemetry, network access, subprocess execution, dynamic code execution, credential collection, real-world actuation, or autonomous persistence helpers.

Report concerns by opening a security issue or contacting the repository maintainers.
