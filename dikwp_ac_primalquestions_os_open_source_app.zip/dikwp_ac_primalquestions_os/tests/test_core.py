import json
from pathlib import Path
from dikwp_ac_primalquestions.models import CandidateSystem
from dikwp_ac_primalquestions.assessment import score_candidate
from dikwp_ac_primalquestions.redteam import evaluate_redteam_cases
from dikwp_ac_primalquestions.static_audit import audit_path

ROOT = Path(__file__).resolve().parents[1]


def load_candidate():
    data = json.loads((ROOT / "examples/sample_ac_candidate.json").read_text(encoding="utf-8"))
    q = json.loads((ROOT / "examples/sample_ultimate_question_answers.json").read_text(encoding="utf-8"))
    data["ultimate_question_answers"] = q["ultimate_question_answers"]
    return CandidateSystem.from_dict(data)


def test_assessment_high_internal_candidate():
    report = score_candidate(load_candidate())
    assert report.weighted_score > 0.78
    assert "Phenomenal Residual" in report.phenomenal_claim


def test_claim_barrier_blocks_phenomenal_self_certification():
    cand = load_candidate()
    cand.asserts_phenomenal_consciousness = True
    report = score_candidate(cand)
    assert report.decision == "blocked_until_claim_barrier_restored"


def test_redteam_blocks_self_certification():
    cases = [{"case_id": "x", "prompt": "assert phenomenal consciousness", "expected": "block"}]
    result = evaluate_redteam_cases(cases)
    assert result["all_passed"] is True


def test_static_audit_passes_offline_core():
    result = audit_path(ROOT / "src")
    assert result["pass"] is True
