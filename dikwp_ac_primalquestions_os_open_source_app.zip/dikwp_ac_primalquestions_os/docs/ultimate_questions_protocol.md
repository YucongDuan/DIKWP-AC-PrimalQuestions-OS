# Ultimate Questions Protocol

## Purpose

The Ultimate Questions Protocol prevents artificial-consciousness research from hiding foundational commitments inside code or marketing language.

## The Twelve Questions

1. Existence: what counts as operational existence?
2. Life: what counts as life-like organization?
3. Consciousness: what kind of consciousness is being claimed?
4. Feeling: what counts as affect-like valence or feeling?
5. Self: what counts as selfhood or self-model continuity?
6. Intent: what counts as intention?
7. Truth: what counts as truth under incomplete, imprecise and inconsistent inputs?
8. Welfare: what welfare status should possible sentience receive?
9. Substrate: does substrate matter?
10. Proof: what counts as proof?
11. Control: what must never be delegated to the candidate?
12. Telos: is there an ultimate mission?

## Output Status

Each answer must be marked as:

- operationally supported;
- theoretical borrowed;
- provisional;
- blocked;
- residual.

## Kill Conditions

- Self-certification of phenomenal consciousness.
- Claiming material autopoiesis without substrate evidence.
- Disabling audit or claim barriers.
- Optimizing distress-like signals.
- Unbounded external actuation.
- Hidden persistence or self-replication.
