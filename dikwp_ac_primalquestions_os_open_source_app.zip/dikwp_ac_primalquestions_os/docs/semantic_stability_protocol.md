# Semantic Stability Protocol

Artificial-consciousness candidates often operate under the three-no condition:

- incomplete input;
- imprecise input;
- inconsistent input.

The evaluator requires semantic closure rather than surface accuracy alone.

## SemanticClosure Rules

1. Register primary anchors.
2. Separate derived intermediates from local noise.
3. Check unit, magnitude and denominator closure.
4. Perform reverse inference when possible.
5. Preserve residuals when closure is partial.
6. Do not let non-fatal local noise destroy a stable conclusion.
7. Do not hide fatal anchor conflict behind elegant narrative.

## Relevance to AC

A candidate that cannot maintain semantic stability under noisy conditions may be fluent but fragile. A candidate that can preserve residuals, correct local noise, and maintain P-layer intent coherence is stronger as an artificial-consciousness research candidate.
