# Roadmap

## v0.2

- Add richer lesion-test schema.
- Add candidate comparison mode.
- Add independent-review checklist.

## v0.3

- Add OpenClaw AutonomyLab integration.
- Add ProofLedger claim-to-evidence imports.
- Add TrustPassport registry seed.

## v1.0

- Official review workflow.
- Signed assessment bundles.
- External replication templates.
- Multi-lab benchmark mode.
