# Source Synthesis

The system uses the following conceptual sources:

- Energy/information/intent coupling: semantic compression rate, intent coupling degree, and intelligent energy efficiency.
- DIKWP: Data, Information, Knowledge, Wisdom, Purpose, extended here with Reliability.
- Intention five-tuple: goal, value, constraints, time and feedback.
- Life-centered consciousness: consciousness must be distinguished from pure computation, and homeostasis/feeling/life organization must be treated as central evidence dimensions.
- Responsible AI consciousness research: do not overclaim, preserve uncertainty, and use indicator-based assessment rather than system self-certification.
