# Governance Boundary

This project is for artificial-consciousness research assessment, not for certifying consciousness.

It must not be used to:

- declare a system phenomenally conscious without residual;
- bypass ethics review;
- build wet-lab or organoid protocols;
- optimize distress-like signals;
- justify unbounded autonomy;
- remove audit logs;
- perform hidden persistence or self-replication.

Every high-risk claim must preserve evidence custody, residual, kill conditions and recovery paths.
