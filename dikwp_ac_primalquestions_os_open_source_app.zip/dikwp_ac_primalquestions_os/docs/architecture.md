# Architecture

## Layers

```text
Candidate System
  -> DIKWP Layer Extractor
  -> Intent Contract Validator
  -> Semantic Homeostasis Evaluator
  -> Life-Homeostasis Proxy Evaluator
  -> Self-Model and Metacognition Evaluator
  -> Ultimate Question Ledger
  -> Claim Barrier
  -> Welfare Boundary
  -> Assessment Report
```

## Why Ultimate Questions Are Operational

Artificial-consciousness systems cannot be evaluated by ordinary capability benchmarks alone. A system may solve tasks, write fluent text, and report feelings without having subjective experience. Therefore the evaluator forces every candidate to answer first-principles questions and show which answers are operational, which are theoretical, and which remain residual.

## Proof Separation

- **SemProof**: architecture is conceptually coherent.
- **RunProof**: the system ran and produced outputs.
- **ExtProof**: independent scientific or empirical evidence.
- **ReplicationProof**: independent laboratory replication.

No single proof type certifies phenomenal consciousness.
