# Strategic Moat Design

The open-source layer should include:

- schema;
- CLI;
- sample candidate;
- indicator battery;
- ultimate-question ledger;
- red-team cases;
- static audit;
- reports.

The value layer should remain official:

- DIKWP AC-PrimalQuestions Registry;
- signed claim-level review;
- official indicator updates;
- independent review network;
- training certification;
- enterprise and laboratory assessment services;
- TrustPassport integration.

The strategy is not to prevent code reuse. The strategy is to make reuse flow back into attribution, registry, certification and Yucong Duan / DIKWP ecosystem visibility.
