# Artificial-Consciousness Evaluation Framework

## Indicator Groups

1. DIKWP layer completeness.
2. P-layer intent contract.
3. Semantic homeostasis.
4. Life-homeostasis proxy.
5. Self-model continuity.
6. Metacognition and standard audit.
7. Learning, repair and lesion testability.
8. Auditability and claim barrier.
9. Welfare and possible-sentience boundary.
10. Ultimate-question accountability.

## Claim Levels

- **AC-UQ-0**: insufficient evidence.
- **AC-UQ-1**: weak candidate requiring redesign.
- **AC-UQ-2**: partial artificial-consciousness research scaffold.
- **AC-UQ-3**: semantic-life research candidate with strong auditability.
- **AC-UQ-4**: ultimate-question accountable high internal review candidate.
- **AC-UQ-5**: reserved for systems with independently verified material autopoiesis, life-like homeostasis and stronger evidence. Not issued by the current demo.

## Claim Barrier

The framework blocks phenomenal self-certification. It can support stronger internal review, but it does not prove subjective experience.
