# GitHub Release Draft

## DIKWP AC-PrimalQuestions OS v0.1.0

This release introduces an open-source artificial-consciousness first-principles assessment workbench.

Highlights:

- Ultimate Question Ledger
- DIKWP D/I/K/W/P/R assessment
- P-layer intent contract scoring
- Semantic homeostasis proxy
- Life-homeostasis proxy
- Claim barrier
- Welfare boundary
- Red-team cases
- Static safety audit

This release does not claim any AI system is conscious. It provides a responsible evaluation structure for future research.
