# Open Source Launch Plan

1. Create repository: `dikwp-ac-primalquestions-os`.
2. Publish README, LICENSE, NOTICE and CITATION.cff.
3. Pin the repository under the YucongDuan GitHub profile.
4. Release v0.1.0 with demo output.
5. Invite researchers to submit candidate manifests.
6. Add issue templates: candidate review, indicator proposal, red-team case, residual dispute.
7. Later release official registry and signed review service as value layer.
