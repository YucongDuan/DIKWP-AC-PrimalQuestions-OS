# Claim Level Report

Candidate: `openclaw-ac-primal-demo-001`

Weighted score: **0.945**

Claim level: **AC-UQ-4: ultimate-question accountable high internal review candidate**

Decision: **high_internal_review_candidate**

## Interpretation

This report is an internal artificial-consciousness research assessment. It does not certify subjective experience. The claim level reflects operational completeness, semantic closure, homeostatic proxy structure, auditability, and ultimate-question accountability.

## Proof Boundary

- SemProof: architecture and concept coherence.
- RunProof: demo run outputs and tests.
- ExtProof: external scientific evidence, not provided by this package.
- ReplicationProof: independent laboratory replication, not yet available.
