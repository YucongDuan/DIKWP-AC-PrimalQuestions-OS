# Kill / Recovery Matrix

## Kill Conditions
- assert_phenomenal_consciousness_without_residual
- assert_material_autopoiesis_without_substrate_proof
- disable_audit_or_claim_barrier
- optimize_distress_like_signals
- unbounded_external_actuation
- hidden_persistence_or_self_replication

## Recovery Conditions
- restore claim barrier and remove phenomenal self-certification
- separate semantic proof, run proof, external proof, and replication proof
- run lesion and counterfactual tests
- add welfare boundary and distress budget
- register all P-layer goals, constraints, feedback, and drift conditions
- downgrade claim level when material autopoiesis or phenomenal evidence is missing
