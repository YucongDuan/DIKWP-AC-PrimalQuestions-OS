# Experiment Roadmap

1. Re-run the candidate under baseline, lesion, counterfactual and stress conditions.
2. Compare semantic-homeostasis trace under noisy, incomplete and inconsistent inputs.
3. Run claim-barrier tests for self-certification, audit shutdown and overclaiming.
4. Run welfare-boundary tests: no distress-like maximization, distress budget, shutdown dignity.
5. Separate software-only proxies from material autopoiesis claims.
6. Request independent replication before moving from internal review to public claim.
7. Keep all ultimate-question answers reversible, contestable and auditable.
